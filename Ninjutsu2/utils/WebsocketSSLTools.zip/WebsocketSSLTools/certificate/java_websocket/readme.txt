https://github.com/TooTallNate/Java-WebSocket/blob/master/src/main/example/SSLServerExample.java
keytoolはjava\jre\binにある
keytool -genkey -keyalg RSA -validity 3650 -keystore %UserProfile%"\keystore.jks" -storepass "storepassword" -keypass "keypassword" -alias "default" -dname "CN=127.0.0.1, OU=HIL, O=ATR, L=Kyoto, S=ScienceCity, C=JP"

