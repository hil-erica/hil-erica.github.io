[SSLWebSocketBridge]
1つのWebsocketで複数のTCPポートのコネクションをProxyする
WebsocketのStringを以下のプロトコルでやりとりして複数のポートにコマンドを分ける
\nがフッター
送信先は受信元と同じポート番号のクライアントにデータを出力する
例
tcpserver 2000 -> websocket -> ... -> websocekt -> tcpclient 2000@127.0.01
tcpserver 2001 -> websocket -> ... -> websocekt -> tcpclient 2001@127.0.01

引数
websocketport=int
tcpclient=int@host
tcpserver=int
tcpserverとtcpclientは複数指定できる

[SSLWebSocketBridge4Kagebunshin]
SSLWebSocketBridgeと使い側は同じ
影分身のWebsocketのforward=コマンドを使ったヘッダーがついている

[SSLWebSocketUDPStreamer]
Websocket(wssプロトコル)をUDP
影分身でMediaRecorderのデータをWebsocket

引数
websocket port, target port@target host,....
